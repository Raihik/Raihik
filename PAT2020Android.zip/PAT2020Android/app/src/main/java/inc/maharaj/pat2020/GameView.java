package inc.maharaj.pat2020;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;

import androidx.core.view.MotionEventCompat;

public class GameView extends SurfaceView implements Runnable {

    volatile boolean isPlaying;
    private Thread gameThread;
    private Protagonist protagonist;
    private SurfaceHolder surfaceHolder;
    private Canvas canvas;
    private Paint paint;
    private Bitmap runPro[];
    private int runningAnimationIndex=0;
    private Background defaultBackground;
    private Antagonist dio;
    private Platforms platforms[];
    private Rect proHitBoxes[];
    private int screenX,screenY;


    public GameView(Context context, int screenX, int screenY) {
        super(context);

        this.screenX=screenX;
        this.screenY=screenY;
        platforms=new Platforms[10];

        for(int i=0;i<platforms.length;i++){

            platforms[i]=new Platforms(context,screenX,screenY);
        }

        Paint paint= new Paint();
        surfaceHolder = getHolder();

        defaultBackground = new Background(context,screenX,screenY);
        protagonist= new Protagonist(context,screenX,screenY);
        dio= new Antagonist(context,screenX,screenY);


       runPro= protagonist.getRunningAnimation();
       proHitBoxes= protagonist.getProHitboxes();
    }

    @Override
    public void run() {

        while(isPlaying) {
            update();
            draw();
            control();
        }
    }

    public void update()  {

        if(protagonist.getIsOnShip()){

        }
        for(int i =0; i<runPro.length;i++) {
            for(int p =0; p<platforms.length;p++){

//                if(protagonist.getRunning()==true){
                    if (Rect.intersects(proHitBoxes[i],platforms[p].getShipHitBox())){


                        protagonist.isOnShip(true);


                        protagonist.setShipY(platforms[p].getShipHitBox().top);


    if(proHitBoxes[i].bottom>platforms[p].getShipHitBox().left || proHitBoxes[i].bottom>platforms[p].getShipHitBox().left|| protagonist.getX()>platforms[p].getShipHitBox().centerX()) {

        if(!protagonist.getRunning()) {

            protagonist.setY(platforms[p].getShipHitBox().top-(proHitBoxes[i].bottom-protagonist.getY()) );
            protagonist.isOnShip(true);
       // }
    }

}
              }

//
//                if(proHitBoxes[i].bottom>platforms[p].getShipHitBox().top){
//                    protagonist.isOnShip(true);
//
//
//                }else{
//                    protagonist.isOnShip(false);
//                }
            }
        }

        for(int i=0;i<platforms.length;i++){

            platforms[i].update();

        }

        protagonist.update();
        defaultBackground.update();
        dio.update();

    }

    public void control(){

        try {


            gameThread.sleep(17);
        }catch (InterruptedException e ){

        }
    }

    public void draw() {



        if (runningAnimationIndex == runPro.length) {

            runningAnimationIndex = 0;
        }


        if (surfaceHolder.getSurface().isValid()) {

            canvas = surfaceHolder.lockCanvas();


            canvas.drawColor(Color.argb(255, 0, 0, 0));


            try {
                gameThread.sleep(20);
            }catch (InterruptedException e){

          }

            canvas.drawBitmap(defaultBackground.getBackground(),defaultBackground.getX(),defaultBackground.getY(),paint);

            for(int i=0;i<platforms.length;i++){

                if(i>2){
                    canvas.drawBitmap(platforms[i].getAirship(),platforms[i].getShipX(),platforms[i].getShipY(),paint);
                }else {

                       if(platforms[i].isShooting() || defaultBackground.isShoot()) {

                           platforms[i].setShooting(true);

                           canvas.drawBitmap(platforms[i].getArrow(), platforms[i].getArrowX(), platforms[i].getArrowY(), paint);

                           canvas.drawBitmap(defaultBackground.getClock(), 0, 20,paint);

                       }

                }

            }



            canvas.drawBitmap(dio.getAntagonistFlying(),dio.getX(),dio.getY(),paint);
            canvas.drawBitmap(runPro[runningAnimationIndex], protagonist.getX(), protagonist.getY(), paint);





            runningAnimationIndex++;

            surfaceHolder.unlockCanvasAndPost(canvas);
        }

    }

    public void pause(){
        isPlaying=false;

        try {
            gameThread.join();
        }catch (InterruptedException e){
            e.printStackTrace();
        }



    }

    public void resume(){
        isPlaying=true;

        gameThread = new Thread(this);
        gameThread.start();

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        switch (MotionEventCompat.getActionMasked(event)){

            case MotionEvent.ACTION_UP:

                    protagonist.setRunning(true);
                    protagonist.setKick(false);


                break;

            case MotionEvent.ACTION_DOWN:

                protagonist.setRunning(false);
                break;


        }


        return true;
    }



}
