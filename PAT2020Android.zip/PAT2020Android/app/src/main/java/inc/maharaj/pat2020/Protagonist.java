package inc.maharaj.pat2020;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.http.SslCertificate;
import android.util.Log;

public class Protagonist {

    private final int jumpHeight=100;;
    private final int groundY=500;
    boolean maxHeight;
    boolean jump;
    private Rect proHitbox;
    private double jumpInterval;
    private int x;
    private int y;
    private boolean running=true;
    private boolean kick=false;
    private Bitmap runningAnimation[];
    private int run[];
    private int fly[];
    private int temp[];
    private int sprites[];
    private int totalJump;
    private int bottomProY;
    Resources resources;
    private int screenY;
    private boolean isOnShip;
    private Rect[] proHitboxes;
    private int shipY;
    private int shipX;

    Protagonist(Context context, int screenX,int screenY){

       resources=context.getResources();
        isOnShip=false;
        this.screenY=screenY;
        proHitbox= new Rect();

        temp= new int[4];
        temp=run;

        fly= new int[]{R.drawable.suspended_1, R.drawable.suspended_2,R.drawable.suspended_3,R.drawable.suspended_4};
        run= new int[]{R.drawable.run_first_last,R.drawable.run_two,R.drawable.run_three,R.drawable.run_four};

        sprites=run;

        runningAnimation= new Bitmap[run.length];
        proHitboxes= new Rect[run.length];






        x=10;
        y=groundY;




           for(int i=0; i<runningAnimation.length;i++){



                runningAnimation[i]= BitmapFactory.decodeResource(resources, sprites[i]);
                runningAnimation[i]=Bitmap.createScaledBitmap(runningAnimation[i],runningAnimation[i].getWidth()/2,runningAnimation[i].getHeight()/2,true);

               bottomProY= runningAnimation[i].getHeight()+y;


               proHitboxes[i]= new Rect();
               proHitboxes[i].right=x+runningAnimation[i].getWidth();
               proHitboxes[i].left=x;
               proHitboxes[i].bottom= y+runningAnimation[i].getHeight();
               proHitboxes[i].top=y;


           }



        jumpInterval= 1;

        maxHeight=false;



    }

    public void update(){


        for(int i=0; i<runningAnimation.length;i++){



            runningAnimation[i]= BitmapFactory.decodeResource(resources, sprites[i]);
            runningAnimation[i]=Bitmap.createScaledBitmap(runningAnimation[i],runningAnimation[i].getWidth()/2,runningAnimation[i].getHeight()/2,true);

            bottomProY= runningAnimation[i].getHeight()+y;


            proHitboxes[i]= new Rect();
            proHitboxes[i].right=x+runningAnimation[i].getWidth();
            proHitboxes[i].left=x;
            proHitboxes[i].bottom= y+runningAnimation[i].getHeight();
            proHitboxes[i].top=y;


        }

            totalJump = shipY - jumpHeight;
            System.out.println("this is: " + totalJump + " the normal y " + y + " this is the ship y " + shipY);


            for (int i = 0; i < runningAnimation.length; i++) {

                proHitboxes[i].right = x + runningAnimation[i].getWidth();
                proHitboxes[i].left = x;
                proHitboxes[i].bottom = y + runningAnimation[i].getHeight();
                proHitboxes[i].top = y;

            }


            for (int i = 0; i < runningAnimation.length; i++) {


                if (proHitboxes[i].bottom > screenY || proHitboxes[i].top < 0) {

                    y = 0;
                }
            }


            if (isOnShip) {

                 sprites=run;

                maxHeight = false;

                if (!running) {



                    while(maxHeight==false) {
                        if (!maxHeight) {

                            y -= jumpInterval;

                            if (y <= totalJump) {
                                maxHeight = true;
                                running=true;
                                System.out.println("yip this happened");
                            }
                        }
                 }

                    System.out.println("max height " + maxHeight);
                }

                isOnShip = false;
            } else {
sprites=fly;

                y +=40;

            }




        }



//        if(jump){
//
//                if(!maxHeight) {
//
//                    y -=jumpInterval;
//                    if(y<totalJump){
//                        maxHeight=true;
//                    }
//                }





    public int getY() {
        return y;
    }

    public int getX() {
        return x;
    }


    public void setRunning(boolean running) {
        this.running = running;
    }

    public boolean getRunning(){ return running; }

    public boolean getKick(){ return kick;}

    public void setKick(boolean kick) {
        this.kick = kick;
    }

    public Bitmap[] getRunningAnimation() {
        return runningAnimation;
    }

    public int getBottomProY() {
        return bottomProY;
    }


    public void isOnShip(boolean onShip) {

        isOnShip=onShip;
    }

    public Rect[] getProHitboxes() {
        return proHitboxes;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setShipY(int shipY ){

        this.shipY=shipY;
    }

    public int[] getFly() {
        return fly;
    }

    public boolean getIsOnShip() {
        return isOnShip;
    }
}
