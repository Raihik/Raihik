package inc.maharaj.pat2020;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//Implements the interface for the Onclicklistener in order to detect if the button has been clicked
public class HomeGUI extends Activity implements View.OnClickListener {
//Creating an object of a Button
    Button playButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //This sets the view to be set to the HomeGUI
        setContentView(R.layout.activity_home_gui);

        //The play button intstantiation and referring to button in the HomeGUI
        playButton= (findViewById(R.id.playButton));
        //This adds a listener(detector) which checks if the button has been clicked
        playButton.setOnClickListener(this);

    }

//This method will handled what to do if the button has been clicked
    @Override
    public void onClick(View v) {

        //Intent is used to create a communication between the two activities
        //In this case if the button is clicked then a new activity is opened and this one is closed
        playButton.setBackgroundColor(Color.LTGRAY);
        Intent gameIntent = new Intent(this, GameController.class);
        startActivity(gameIntent);
        finish();
    }

}
