package inc.maharaj.pat2020;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import java.lang.ref.PhantomReference;
import java.security.PrivateKey;
import java.util.Random;

public class Platforms {

    private Random randomizer;
    private boolean isShooting;
    private Bitmap arrow;
    private Bitmap airship;
    private int shipX,shipY;
    private int arrowX,arrowY;
    private int screenX, screenY;
    private Protagonist pro;
    private int randomCoord[];
    private int speed;
    private Bitmap[] platforms;
    private int platformResources[];
    private Rect arrowHitbox,shipHitBox;




    public Platforms(Context context, int screenX, int screenY){

        arrowHitbox=new Rect();
        shipHitBox=new Rect();


        pro=new Protagonist(context,screenX,screenY);
        randomCoord= new int[4];

        platformResources= new int[]{R.drawable.arrow,R.drawable.airship};
        platforms= new Bitmap[platformResources.length];


      for(int i =0; i<platformResources.length;i++){
          platforms[i]= BitmapFactory.decodeResource(context.getResources(),platformResources[i]);
          platforms[i]=Bitmap.createScaledBitmap(platforms[i],platforms[i].getWidth()/5,platforms[i].getHeight()/5,true);

      }

        arrow=platforms[0];
        airship=platforms[1];

        arrowHitbox.top=arrowY;
        arrowHitbox.left=arrowX;
        arrowHitbox.bottom=arrowY+arrow.getHeight();
        arrowHitbox.right=arrowX+arrow.getWidth();

        shipHitBox.top=shipY;
        shipHitBox.left=shipX;
        shipHitBox.bottom=shipY+airship.getHeight();
        shipHitBox.right=shipX+airship.getWidth();

        randomizer= new Random();

        for(int i =0; i<randomCoord.length;i++) {

            if(i>=2){
                randomCoord[i]=randomizer.nextInt(((screenX+200)-screenX)+1)+screenX;

            }
            randomCoord[i] = randomizer.nextInt((screenY - pro.getBottomProY()) + 1) + pro.getBottomProY();


        }


        this.screenX=screenX;
        this.screenY=screenY;

        arrowY=randomCoord[0];
        shipY=randomCoord[1];
        arrowX=randomCoord[2];
        shipX=randomCoord[3];
        speed=randomizer.nextInt((50-20)+1)+20;



        isShooting=false;
        shipX=pro.getX();
        shipY=pro.getY()+80;


    }


    public void update(){


        arrowHitbox.top=arrowY;
        arrowHitbox.left=arrowX;
        arrowHitbox.bottom=arrowY+arrow.getHeight();
        arrowHitbox.right=arrowX+arrow.getWidth();

        shipHitBox.top=shipY;
        shipHitBox.left=shipX;
        shipHitBox.bottom=shipY+airship.getHeight();
        shipHitBox.right=shipX+airship.getWidth();

      arrowX-=speed;
      shipX-=speed;



      if(shipX-arrowX <40 || arrowX-shipX <40){

          arrowX-=10;
      }

      //make more efficient
        for(int i =0; i<randomCoord.length;i++) {

            if(i==2){
                randomCoord[i]=randomizer.nextInt(((screenX+200)-screenX)+1)+screenX;


            }
            randomCoord[i] = randomizer.nextInt((screenY - pro.getBottomProY()) + 1) + pro.getBottomProY();

        }


        if(arrowX+arrow.getWidth()<0){

            arrowX=randomCoord[2];
            arrowY=randomCoord[0];
           isShooting=false;

        }

        if(shipX+airship.getWidth()<0){
            shipX=randomCoord[3];
            shipY=randomCoord[1];
//            shipX=pro.getX();
//            shipY=pro.getY();
        }





    }


    public Bitmap getAirship() {
        return airship;
    }

    public Bitmap getArrow() {
        return arrow;
    }

    public int getArrowX() {
        return arrowX;
    }

    public int getArrowY() {
        return arrowY;
    }

    public int getShipX() {
        return shipX;
    }

    public int getShipY() {
        return shipY;
    }


    public void setArrowX(int arrowX) {
        this.arrowX = arrowX;
    }

    public void setShipX(int shipX) {
        this.shipX = shipX;
    }


    public void setShooting(boolean shooting) {
        isShooting = shooting;
    }

    public boolean isShooting() {
        return isShooting;
    }

    public Rect getArrowHitbox() {
        return arrowHitbox;
    }

    public Rect getShipHitBox() {
        return shipHitBox;
    }




}

