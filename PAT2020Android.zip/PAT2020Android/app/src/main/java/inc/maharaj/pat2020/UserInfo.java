package inc.maharaj.pat2020;

import android.app.Activity;
import android.os.Bundle;

public class UserInfo extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //code for userInfo Gui will go here
    }


}
