package inc.maharaj.pat2020;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.Display;

public class GameController extends Activity {

    GameView gameView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Display display = getWindowManager().getDefaultDisplay();

        Point screenSize=new Point();

        display.getSize(screenSize);
        gameView= new GameView(this,screenSize.x,screenSize.y);

        setContentView(gameView);

    }


    @Override
    protected void onResume() {
        super.onResume();

        gameView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();

        gameView.pause();
    }
}
