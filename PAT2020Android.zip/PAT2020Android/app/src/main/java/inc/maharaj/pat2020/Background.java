package inc.maharaj.pat2020;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class Background {

    private final int backgroundSpeed=20;
    private int x;
    private int y;
    private Bitmap background;
    private int screenX;
    private Platforms platforms;
    private boolean shoot;
    private Bitmap clock;

    public Background(Context context, int screenX, int screenY){

        clock= BitmapFactory.decodeResource(context.getResources(),R.drawable.dio_clock);
        clock= Bitmap.createScaledBitmap(clock,clock.getWidth()/10,clock.getHeight()/10,true);


        shoot=false;
        platforms=new Platforms(context,screenX,screenY);
        this.screenX=screenX;
        x=0;
        y=0;
        background= BitmapFactory.decodeResource(context.getResources(),R.drawable.game_background);
        //background=Bitmap.createScaledBitmap(background,background.getWidth()*2,background.getHeight()*2,true);



    }

    public void update(){

          x-=backgroundSpeed;

          if(background.getWidth()+x==screenX){

              x=0;



          }

          if(x==0){

              shoot=true;
              platforms.setShooting(true);
          }else {
              shoot=false;
          }

    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Bitmap getBackground() {
        return background;
    }

    public boolean isShoot() {
        return shoot;
    }

    public Bitmap getClock() {
        return clock;
    }
}
