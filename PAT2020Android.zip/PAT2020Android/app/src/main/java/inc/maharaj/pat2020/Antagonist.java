package inc.maharaj.pat2020;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class Antagonist {

   private Bitmap antagonistFlying,antagonistStand;
   private int x;
   private int y;
   private int screenX,screenY;


public Antagonist(Context context, int screenX, int screenY){

    antagonistStand= BitmapFactory.decodeResource(context.getResources(),R.drawable.antagonist_shoot);
    antagonistStand= Bitmap.createScaledBitmap(antagonistStand,antagonistStand.getWidth()/4,antagonistStand.getHeight()/4,true);

    antagonistFlying= BitmapFactory.decodeResource(context.getResources(),R.drawable.antagonist_flying);
    antagonistFlying= Bitmap.createScaledBitmap(antagonistFlying,antagonistFlying.getWidth()/4,antagonistFlying.getHeight()/4,true);

    this.screenX=screenX;
    this.screenY=screenY;


    x=screenX-antagonistFlying.getWidth();
    y=50;


}

boolean maxReached=false;
public void update(){

if(y==50){
    maxReached=false;
}

if(y>=50 && maxReached==false){

    y+=2;

}

if(y==80){
    maxReached=true;
}

if(maxReached){
    y-=2;
}

}


    public int getY() {
        return y;
    }

    public int getX() {
        return x;
    }

    public Bitmap getAntagonistStand() {
        return antagonistStand;
    }

    public Bitmap getAntagonistFlying() {
        return antagonistFlying;
    }
}
